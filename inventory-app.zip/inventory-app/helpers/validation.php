<?php
// helpers/validation.php

function sanitize_input($data) {
    return trim($data ?? '');
}

function validate_positive_int($value) {
    $val = filter_var($value, FILTER_VALIDATE_INT);
    return ($val !== false && $val > 0) ? $val : false;
}

function validate_non_negative_int($value) {
    $val = filter_var($value, FILTER_VALIDATE_INT);
    return ($val !== false && $val >= 0) ? $val : false;
}