<?php
// helpers/auth.php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function require_login() {
    if (!isset($_SESSION['user'])) {
        header("Location: /inventory-app/public/login.php");
        exit;
    }
}

function require_role($allowed_roles = []) {
    require_login();
    if (!in_array($_SESSION['user']['role'], (array)$allowed_roles)) {
        http_response_code(403);
        echo "<div style='padding:20px; font-family:sans-serif; color:red;'><h1>403 Forbidden</h1><p>Anda tidak memiliki hak akses untuk membuka halaman ini.</p><a href='/inventory-app/public/dashboard.php'>Kembali ke Dashboard</a></div>";
        exit;
    }
}

function current_user() {
    return $_SESSION['user'] ?? null;
}