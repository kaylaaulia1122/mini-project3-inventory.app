<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../helpers/validation.php';
require_once __DIR__ . '/../../views/header.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $product_id = validate_positive_int($_POST['product_id'] ?? null);
    $quantity = validate_positive_int($_POST['quantity'] ?? null);
    $notes = sanitize_input($_POST['notes'] ?? '');

    if (!$product_id || !$quantity) {
        $error = 'Produk dan Jumlah barang keluar wajib diisi dengan valid.';
    } else {
        try {
            // DATABASE TRANSACTION DENGAN ROW LOCKING
            $pdo->beginTransaction();

            // 1. Lock Baris Produk & Cek Stok Tersedia
            $stmtLock = $pdo->prepare("SELECT stock FROM products WHERE id = :id FOR UPDATE");
            $stmtLock->execute(['id' => $product_id]);
            $current_stock = $stmtLock->fetchColumn();

            // BUSINESS RULE: STOK TIDAK BOLEH NEGATIF
            if ($current_stock < $quantity) {
                throw new Exception("Stok tidak mencukupi! Stok fisik saat ini hanya tersisa $current_stock unit.");
            }

            // 2. Kurangi Stok
            $stmt1 = $pdo->prepare("UPDATE products SET stock = stock - :qty WHERE id = :id");
            $stmt1->execute(['qty' => $quantity, 'id' => $product_id]);

            // 3. Catat Movement
            $stmt2 = $pdo->prepare("INSERT INTO stock_movements (product_id, user_id, type, quantity, notes) VALUES (:product_id, :user_id, 'OUT', :qty, :notes)");
            $stmt2->execute([
                'product_id' => $product_id,
                'user_id'    => current_user()['id'],
                'qty'        => $quantity,
                'notes'      => $notes
            ]);

            $pdo->commit();
            header("Location: history.php");
            exit;
        } catch (Throwable $e) {
            $pdo->rollBack();
            $error = $e->getMessage();
        }
    }
}

$products = $pdo->query("SELECT id, name, sku, stock FROM products ORDER BY name ASC")->fetchAll();
?>

<div class="max-w-xl mx-auto space-y-6">
    <div class="flex items-center justify-between">
        <a href="/inventory-app/public/dashboard.php" class="text-xs font-semibold text-slate-500 hover:text-slate-800 flex items-center gap-1.5 transition">
            <i class="fa-solid fa-arrow-left"></i> Kembali ke Dashboard
        </a>
        <span class="text-xs font-semibold text-amber-600 bg-amber-50 px-2.5 py-1 rounded-md border border-amber-200/50">Form Pengeluaran Barang</span>
    </div>

    <div class="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200/80 shadow-sm">
        <div class="flex items-center gap-3 pb-5 mb-6 border-b border-slate-100">
            <div class="w-11 h-11 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center text-lg">
                <i class="fa-solid fa-circle-arrow-up"></i>
            </div>
            <div>
                <h2 class="text-xl font-bold text-slate-900">Pencatatan Barang Keluar</h2>
                <p class="text-xs text-slate-400">Pengurangan stok fisik untuk penjualan atau pengiriman</p>
            </div>
        </div>

        <?php if ($error): ?>
            <div class="bg-rose-50 border border-rose-200 text-rose-700 text-xs p-3.5 rounded-2xl mb-6 flex items-center gap-2">
                <i class="fa-solid fa-triangle-exclamation text-rose-500 text-sm"></i>
                <span class="font-bold"><?= e($error) ?></span>
            </div>
        <?php endif; ?>

        <form method="POST" class="space-y-4">
            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">

            <div>
                <label class="block text-xs uppercase font-bold text-slate-600 mb-1.5">Pilih Produk Elektronik *</label>
                <select name="product_id" required class="w-full border border-slate-200 p-2.5 rounded-xl text-sm bg-white focus:outline-none focus:ring-2 focus:ring-amber-500">
                    <option value="">-- Pilih Produk --</option>
                    <?php foreach ($products as $p): ?>
                        <option value="<?= $p['id'] ?>" <?= $p['stock'] <= 0 ? 'disabled class="text-slate-400"' : '' ?>>
                            [<?= e($p['sku']) ?>] <?= e($p['name']) ?> (Tersedia: <?= number_format($p['stock']) ?> unit)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div>
                <label class="block text-xs uppercase font-bold text-slate-600 mb-1.5">Jumlah Barang Keluar (Unit) *</label>
                <input type="number" name="quantity" min="1" placeholder="Masukkan jumlah unit keluar" required class="w-full border border-slate-200 p-2.5 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 bg-slate-50 focus:bg-white transition">
            </div>

            <div>
                <label class="block text-xs uppercase font-bold text-slate-600 mb-1.5">Catatan / Keperluan Pengeluaran</label>
                <textarea name="notes" rows="3" class="w-full border border-slate-200 p-2.5 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 bg-slate-50 focus:bg-white transition" placeholder="Contoh: Pengiriman pesanan Nota #INV-2026-1029 atau distribusi ke cabang"></textarea>
            </div>

            <div class="pt-4 flex items-center gap-3">
                <a href="/inventory-app/public/dashboard.php" class="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold py-2.5 rounded-xl text-xs text-center transition">
                    Batal
                </a>
                <button type="submit" class="flex-1 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white font-semibold py-2.5 rounded-xl text-xs shadow-md shadow-amber-500/25 transition">
                    Simpan Barang Keluar
                </button>
            </div>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/../../views/footer.php'; ?>