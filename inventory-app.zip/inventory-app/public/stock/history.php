<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../views/header.php';

$user = current_user();
$is_admin = ($user['role'] === 'admin');

// Parameter Filter & Skema Periode
$period_scheme = $_GET['period_scheme'] ?? 'all';
$type = $_GET['type'] ?? 'ALL';
$q = trim($_GET['q'] ?? '');
$date_val = $_GET['date'] ?? date('Y-m-d');
$start_date = $_GET['start_date'] ?? date('Y-m-d', strtotime('-6 days'));
$end_date = $_GET['end_date'] ?? date('Y-m-d');
$month = (int)($_GET['month'] ?? date('m'));
$year = (int)($_GET['year'] ?? date('Y'));

// Build Query Filter
$where = ["1=1"];
$params = [];

// Filter Skema Periode
switch ($period_scheme) {
    case 'daily':
        $where[] = "DATE(sm.created_at) = :daily_date";
        $params['daily_date'] = $date_val;
        break;

    case 'weekly':
        $where[] = "DATE(sm.created_at) BETWEEN :w_start AND :w_end";
        $params['w_start'] = $start_date;
        $params['w_end'] = $end_date;
        break;

    case 'monthly':
        $where[] = "MONTH(sm.created_at) = :m_month AND YEAR(sm.created_at) = :m_year";
        $params['m_month'] = $month;
        $params['m_year'] = $year;
        break;

    case 'yearly':
        $where[] = "YEAR(sm.created_at) = :y_year";
        $params['y_year'] = $year;
        break;

    default:
        // 'all'
        break;
}

// Filter Tipe (IN / OUT)
if ($type === 'IN' || $type === 'OUT') {
    $where[] = "sm.type = :type";
    $params['type'] = $type;
}

// Filter Pencarian Teks
if ($q !== '') {
    $where[] = "(p.name LIKE :q OR p.sku LIKE :q OR u.full_name LIKE :q OR sm.notes LIKE :q)";
    $params['q'] = "%$q%";
}

$where_sql = implode(' AND ', $where);

// Fetch Data Histori
$sql = "SELECT sm.*, p.name AS product_name, p.sku, c.name AS category_name, u.full_name AS user_name 
        FROM stock_movements sm 
        JOIN products p ON p.id = sm.product_id 
        JOIN categories c ON c.id = p.category_id 
        JOIN users u ON u.id = sm.user_id 
        WHERE $where_sql 
        ORDER BY sm.created_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$movements = $stmt->fetchAll();

// Hitung Rekapitulasi Bar
$total_in = 0;
$total_out = 0;
foreach ($movements as $m) {
    if ($m['type'] === 'IN') {
        $total_in += (int)$m['quantity'];
    } else {
        $total_out += (int)$m['quantity'];
    }
}
?>

<div class="space-y-6">
    <!-- Top Header -->
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
            <h2 class="text-2xl font-extrabold text-slate-900 tracking-tight">Histori Transaksi Stok</h2>
            <p class="text-xs text-slate-500 mt-1">Audit log seluruh pergerakan barang masuk dan keluar di gudang</p>
        </div>

        <?php if ($is_admin): ?>
            <!-- Tombol Cetak Laporan Khusus Admin (Sesuai Request No. 8) -->
            <div class="relative inline-block text-left">
                <button type="button" onclick="openPrintModal()" class="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white px-4 py-2.5 rounded-xl text-xs font-semibold shadow-md shadow-blue-500/25 transition flex items-center gap-2">
                    <i class="fa-solid fa-print"></i> Cetak Laporan Mutasi...
                </button>
            </div>
        <?php endif; ?>
    </div>

    <!-- Filter & Scheme Card -->
    <div class="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-sm space-y-4">
        <form method="GET" class="space-y-3">
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                <!-- Skema Periode Dropdown -->
                <div>
                    <label class="block text-[11px] uppercase font-bold text-slate-500 mb-1">Skema Periode</label>
                    <select id="schemeSelect" name="period_scheme" onchange="toggleSchemeFields(this.value)" class="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-xs bg-white font-medium focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="all" <?= $period_scheme === 'all' ? 'selected' : '' ?>>Semua Periode</option>
                        <option value="daily" <?= $period_scheme === 'daily' ? 'selected' : '' ?>>📅 Skema Harian</option>
                        <option value="weekly" <?= $period_scheme === 'weekly' ? 'selected' : '' ?>>🗓️ Skema Mingguan</option>
                        <option value="monthly" <?= $period_scheme === 'monthly' ? 'selected' : '' ?>>📊 Skema Bulanan</option>
                        <option value="yearly" <?= $period_scheme === 'yearly' ? 'selected' : '' ?>>📈 Skema Tahunan</option>
                    </select>
                </div>

                <!-- Dynamic Scheme Fields -->
                <!-- Harian Input -->
                <div id="dailyField" class="<?= $period_scheme === 'daily' ? '' : 'hidden' ?>">
                    <label class="block text-[11px] uppercase font-bold text-slate-500 mb-1">Pilih Tanggal</label>
                    <input type="date" name="date" value="<?= e($date_val) ?>" class="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs bg-white focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>

                <!-- Mingguan Input (Start & End) -->
                <div id="weeklyField" class="<?= $period_scheme === 'weekly' ? '' : 'hidden' ?> flex items-center gap-2">
                    <div class="flex-1">
                        <label class="block text-[11px] uppercase font-bold text-slate-500 mb-1">Dari</label>
                        <input type="date" name="start_date" value="<?= e($start_date) ?>" class="w-full px-2 py-2 border border-slate-200 rounded-xl text-xs bg-white focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>
                    <div class="flex-1">
                        <label class="block text-[11px] uppercase font-bold text-slate-500 mb-1">Sampai</label>
                        <input type="date" name="end_date" value="<?= e($end_date) ?>" class="w-full px-2 py-2 border border-slate-200 rounded-xl text-xs bg-white focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>
                </div>

                <!-- Bulanan Input (Month & Year) -->
                <div id="monthlyField" class="<?= $period_scheme === 'monthly' ? '' : 'hidden' ?> flex items-center gap-2">
                    <div class="flex-1">
                        <label class="block text-[11px] uppercase font-bold text-slate-500 mb-1">Bulan</label>
                        <select name="month" class="w-full px-2 py-2.5 border border-slate-200 rounded-xl text-xs bg-white focus:outline-none focus:ring-2 focus:ring-blue-500">
                            <?php
                            $months = [
                                1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April',
                                5 => 'Mei', 6 => 'Juni', 7 => 'Juli', 8 => 'Agustus',
                                9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember'
                            ];
                            foreach ($months as $num => $m_name): ?>
                                <option value="<?= $num ?>" <?= $month == $num ? 'selected' : '' ?>><?= $m_name ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="w-24">
                        <label class="block text-[11px] uppercase font-bold text-slate-500 mb-1">Tahun</label>
                        <input type="number" name="year" value="<?= $year ?>" min="2020" max="2035" class="w-full px-2 py-2 border border-slate-200 rounded-xl text-xs bg-white focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>
                </div>

                <!-- Tahunan Input (Year) -->
                <div id="yearlyField" class="<?= $period_scheme === 'yearly' ? '' : 'hidden' ?>">
                    <label class="block text-[11px] uppercase font-bold text-slate-500 mb-1">Tahun Laporan</label>
                    <input type="number" name="year" value="<?= $year ?>" min="2020" max="2035" class="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs bg-white focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>

                <!-- Jenis Mutasi (Tipe) -->
                <div>
                    <label class="block text-[11px] uppercase font-bold text-slate-500 mb-1">Jenis Mutasi</label>
                    <select name="type" class="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-xs bg-white focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="ALL" <?= $type === 'ALL' ? 'selected' : '' ?>>Semua Jenis (IN & OUT)</option>
                        <option value="IN" <?= $type === 'IN' ? 'selected' : '' ?>>Barang Masuk Saja (IN)</option>
                        <option value="OUT" <?= $type === 'OUT' ? 'selected' : '' ?>>Barang Keluar Saja (OUT)</option>
                    </select>
                </div>

                <!-- Search Input -->
                <div>
                    <label class="block text-[11px] uppercase font-bold text-slate-500 mb-1">Pencarian Cepat</label>
                    <div class="relative">
                        <input type="text" name="q" value="<?= e($q) ?>" placeholder="Produk / SKU / Petugas..." class="w-full pl-8 pr-3 py-2 border border-slate-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-blue-500 bg-slate-50 focus:bg-white transition">
                        <span class="absolute inset-y-0 left-0 pl-2.5 flex items-center pointer-events-none text-slate-400">
                            <i class="fa-solid fa-magnifying-glass text-[10px]"></i>
                        </span>
                    </div>
                </div>
            </div>

            <!-- Action buttons -->
            <div class="flex items-center justify-between pt-2">
                <div class="flex items-center gap-2">
                    <button type="submit" class="bg-slate-800 hover:bg-slate-900 text-white px-4 py-2 rounded-xl text-xs font-semibold transition flex items-center gap-1.5 shadow-xs">
                        <i class="fa-solid fa-filter text-[10px]"></i> Terapkan Filter
                    </button>
                    <?php if ($period_scheme !== 'all' || $type !== 'ALL' || $q !== ''): ?>
                        <a href="history.php" class="bg-slate-100 hover:bg-slate-200 text-slate-600 px-3 py-2 rounded-xl text-xs font-semibold transition flex items-center gap-1">
                            <i class="fa-solid fa-rotate-left text-[10px]"></i> Reset
                        </a>
                    <?php endif; ?>
                </div>

                <?php if ($is_admin): ?>
                    <!-- Quick Print Current Filter Link -->
                    <a href="print.php?period_scheme=<?= urlencode($period_scheme) ?>&type=<?= urlencode($type) ?>&date=<?= urlencode($date_val) ?>&start_date=<?= urlencode($start_date) ?>&end_date=<?= urlencode($end_date) ?>&month=<?= (int)$month ?>&year=<?= (int)$year ?>&auto_print=1" target="_blank" class="text-xs font-semibold text-blue-600 hover:text-blue-700 flex items-center gap-1.5">
                        <i class="fa-solid fa-arrow-up-right-from-square text-[10px]"></i> Cetak Sesuai Filter Ini
                    </a>
                <?php endif; ?>
            </div>
        </form>
    </div>

    <!-- Summary Statistics Bar -->
    <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div class="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs flex items-center justify-between">
            <div>
                <span class="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Total Transaksi</span>
                <span class="text-xl font-black text-slate-900"><?= count($movements) ?></span>
                <span class="text-[11px] text-slate-500"> catatan mutasi</span>
            </div>
            <div class="w-10 h-10 rounded-xl bg-slate-100 text-slate-600 flex items-center justify-center text-sm">
                <i class="fa-solid fa-list-check"></i>
            </div>
        </div>

        <div class="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs flex items-center justify-between">
            <div>
                <span class="text-[10px] font-bold uppercase tracking-wider text-indigo-500 block">Total Masuk</span>
                <span class="text-xl font-black text-indigo-600">+<?= number_format($total_in) ?></span>
                <span class="text-[11px] text-slate-500"> unit diterima</span>
            </div>
            <div class="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center text-sm">
                <i class="fa-solid fa-circle-arrow-down"></i>
            </div>
        </div>

        <div class="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs flex items-center justify-between">
            <div>
                <span class="text-[10px] font-bold uppercase tracking-wider text-amber-500 block">Total Keluar</span>
                <span class="text-xl font-black text-amber-600">-<?= number_format($total_out) ?></span>
                <span class="text-[11px] text-slate-500"> unit dikeluarkan</span>
            </div>
            <div class="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center text-sm">
                <i class="fa-solid fa-circle-arrow-up"></i>
            </div>
        </div>
    </div>

    <!-- Table Card -->
    <div class="bg-white rounded-2xl border border-slate-200/80 shadow-sm overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-left text-sm text-slate-600">
                <thead class="bg-slate-50/80 border-b border-slate-200 font-bold text-slate-700 uppercase text-[11px] tracking-wider">
                    <tr>
                        <th class="p-4">Waktu</th>
                        <th class="p-4">Produk Elektronik</th>
                        <th class="p-4">Kategori</th>
                        <th class="p-4 text-center">Tipe Mutasi</th>
                        <th class="p-4 text-right">Jumlah</th>
                        <th class="p-4">Petugas</th>
                        <th class="p-4">Keterangan / Catatan</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <?php if (empty($movements)): ?>
                        <tr>
                            <td colspan="7" class="p-8 text-center text-slate-400">
                                <i class="fa-solid fa-file-excel text-3xl mb-2 block"></i>
                                Tidak ada transaksi stok yang sesuai dengan filter yang dipilih.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($movements as $m): ?>
                            <tr class="hover:bg-slate-50/70 transition">
                                <td class="p-4 text-xs font-medium text-slate-500 whitespace-nowrap">
                                    <span class="block text-slate-800 font-semibold"><?= date('d/m/Y', strtotime($m['created_at'])) ?></span>
                                    <span class="text-[10px] text-slate-400"><?= date('H:i:s', strtotime($m['created_at'])) ?> WIB</span>
                                </td>
                                <td class="p-4">
                                    <span class="font-bold text-slate-900 block"><?= e($m['product_name']) ?></span>
                                    <span class="font-mono text-xs text-slate-400 font-medium"><?= e($m['sku']) ?></span>
                                </td>
                                <td class="p-4">
                                    <span class="text-xs font-medium bg-slate-100 px-2 py-1 rounded text-slate-600">
                                        <?= e($m['category_name']) ?>
                                    </span>
                                </td>
                                <td class="p-4 text-center">
                                    <span class="px-2.5 py-1 rounded-full text-xs font-bold inline-flex items-center gap-1 <?= $m['type'] === 'IN' ? 'bg-indigo-100 text-indigo-700' : 'bg-amber-100 text-amber-700' ?>">
                                        <i class="fa-solid <?= $m['type'] === 'IN' ? 'fa-arrow-down' : 'fa-arrow-up' ?> text-[10px]"></i>
                                        <?= $m['type'] === 'IN' ? 'MASUK' : 'KELUAR' ?>
                                    </span>
                                </td>
                                <td class="p-4 text-right font-black text-sm <?= $m['type'] === 'IN' ? 'text-indigo-600' : 'text-amber-600' ?>">
                                    <?= $m['type'] === 'IN' ? '+' : '-' ?><?= number_format($m['quantity']) ?> unit
                                </td>
                                <td class="p-4 font-medium text-slate-800">
                                    <div class="flex items-center gap-2">
                                        <span class="w-6 h-6 rounded-full bg-slate-100 text-slate-600 flex items-center justify-center text-[10px] font-bold">
                                            <?= strtoupper(substr($m['user_name'], 0, 1)) ?>
                                        </span>
                                        <span><?= e($m['user_name']) ?></span>
                                    </div>
                                </td>
                                <td class="p-4 text-xs text-slate-500 max-w-xs truncate">
                                    <?= e($m['notes'] ?: '-') ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php if ($is_admin): ?>
    <!-- Modal Cetak Laporan Khusus Admin dengan 4 Skema: Harian, Mingguan, Bulanan, Tahunan -->
    <div id="printModal" class="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs hidden flex items-center justify-center p-4">
        <div class="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200">
            <div class="flex items-center justify-between pb-4 mb-4 border-b border-slate-100">
                <div class="flex items-center gap-3">
                    <span class="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center text-lg">
                        <i class="fa-solid fa-print"></i>
                    </span>
                    <div>
                        <h3 class="text-base font-bold text-slate-900">Cetak Laporan Mutasi Stok</h3>
                        <p class="text-xs text-slate-400">Pilih skema periode pencetakan dokumen resmi</p>
                    </div>
                </div>
                <button type="button" onclick="closePrintModal()" class="text-slate-400 hover:text-slate-600 text-lg">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>

            <!-- 4 Skema Pilihan Cepat -->
            <div class="space-y-3 mb-6">
                <!-- Skema 1: Harian -->
                <a href="print.php?period_scheme=daily&date=<?= date('Y-m-d') ?>&auto_print=1" target="_blank" class="p-3.5 rounded-2xl border border-slate-200 hover:border-blue-500 hover:bg-blue-50/50 transition flex items-center justify-between group">
                    <div class="flex items-center gap-3">
                        <span class="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center text-sm group-hover:scale-105 transition">
                            <i class="fa-solid fa-calendar-day"></i>
                        </span>
                        <div>
                            <span class="text-xs font-bold text-slate-900 block">1. Skema Harian (Hari Ini)</span>
                            <span class="text-[11px] text-slate-400"><?= date('d F Y') ?></span>
                        </div>
                    </div>
                    <span class="text-xs font-semibold text-blue-600 flex items-center gap-1">
                        Cetak <i class="fa-solid fa-arrow-right text-[10px]"></i>
                    </span>
                </a>

                <!-- Skema 2: Mingguan -->
                <a href="print.php?period_scheme=weekly&start_date=<?= date('Y-m-d', strtotime('-6 days')) ?>&end_date=<?= date('Y-m-d') ?>&auto_print=1" target="_blank" class="p-3.5 rounded-2xl border border-slate-200 hover:border-blue-500 hover:bg-blue-50/50 transition flex items-center justify-between group">
                    <div class="flex items-center gap-3">
                        <span class="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center text-sm group-hover:scale-105 transition">
                            <i class="fa-solid fa-calendar-week"></i>
                        </span>
                        <div>
                            <span class="text-xs font-bold text-slate-900 block">2. Skema Mingguan (7 Hari Terakhir)</span>
                            <span class="text-[11px] text-slate-400"><?= date('d M', strtotime('-6 days')) ?> &mdash; <?= date('d M Y') ?></span>
                        </div>
                    </div>
                    <span class="text-xs font-semibold text-blue-600 flex items-center gap-1">
                        Cetak <i class="fa-solid fa-arrow-right text-[10px]"></i>
                    </span>
                </a>

                <!-- Skema 3: Bulanan -->
                <a href="print.php?period_scheme=monthly&month=<?= (int)date('m') ?>&year=<?= date('Y') ?>&auto_print=1" target="_blank" class="p-3.5 rounded-2xl border border-slate-200 hover:border-blue-500 hover:bg-blue-50/50 transition flex items-center justify-between group">
                    <div class="flex items-center gap-3">
                        <span class="w-9 h-9 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center text-sm group-hover:scale-105 transition">
                            <i class="fa-solid fa-calendar-days"></i>
                        </span>
                        <div>
                            <span class="text-xs font-bold text-slate-900 block">3. Skema Bulanan (Bulan Berjalan)</span>
                            <span class="text-[11px] text-slate-400"><?= date('F Y') ?></span>
                        </div>
                    </div>
                    <span class="text-xs font-semibold text-blue-600 flex items-center gap-1">
                        Cetak <i class="fa-solid fa-arrow-right text-[10px]"></i>
                    </span>
                </a>

                <!-- Skema 4: Tahunan -->
                <a href="print.php?period_scheme=yearly&year=<?= date('Y') ?>&auto_print=1" target="_blank" class="p-3.5 rounded-2xl border border-slate-200 hover:border-blue-500 hover:bg-blue-50/50 transition flex items-center justify-between group">
                    <div class="flex items-center gap-3">
                        <span class="w-9 h-9 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center text-sm group-hover:scale-105 transition">
                            <i class="fa-solid fa-chart-line"></i>
                        </span>
                        <div>
                            <span class="text-xs font-bold text-slate-900 block">4. Skema Tahunan (Tahun Penuh)</span>
                            <span class="text-[11px] text-slate-400">Tahun <?= date('Y') ?></span>
                        </div>
                    </div>
                    <span class="text-xs font-semibold text-blue-600 flex items-center gap-1">
                        Cetak <i class="fa-solid fa-arrow-right text-[10px]"></i>
                    </span>
                </a>
            </div>

            <div class="pt-2 text-right">
                <button type="button" onclick="closePrintModal()" class="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition">
                    Tutup
                </button>
            </div>
        </div>
    </div>

    <script>
        function openPrintModal() {
            document.getElementById('printModal').classList.remove('hidden');
        }
        function closePrintModal() {
            document.getElementById('printModal').classList.add('hidden');
        }
    </script>
<?php endif; ?>

<script>
function toggleSchemeFields(val) {
    document.getElementById('dailyField')?.classList.add('hidden');
    document.getElementById('weeklyField')?.classList.add('hidden');
    document.getElementById('monthlyField')?.classList.add('hidden');
    document.getElementById('yearlyField')?.classList.add('hidden');

    if (val === 'daily') {
        document.getElementById('dailyField')?.classList.remove('hidden');
    } else if (val === 'weekly') {
        document.getElementById('weeklyField')?.classList.remove('hidden');
    } else if (val === 'monthly') {
        document.getElementById('monthlyField')?.classList.remove('hidden');
    } else if (val === 'yearly') {
        document.getElementById('yearlyField')?.classList.remove('hidden');
    }
}
</script>

<?php require_once __DIR__ . '/../../views/footer.php'; ?>