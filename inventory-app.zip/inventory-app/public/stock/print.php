<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../helpers/auth.php';
require_once __DIR__ . '/../../helpers/escape.php';

require_role('admin');
$admin = current_user();

// Parameter Skema
$period_scheme = $_GET['period_scheme'] ?? 'all';
$type = $_GET['type'] ?? 'ALL';
$date_val = $_GET['date'] ?? date('Y-m-d');
$start_date = $_GET['start_date'] ?? date('Y-m-d', strtotime('-6 days'));
$end_date = $_GET['end_date'] ?? date('Y-m-d');
$month = (int)($_GET['month'] ?? date('m'));
$year = (int)($_GET['year'] ?? date('Y'));
$auto_print = isset($_GET['auto_print']) && $_GET['auto_print'] == '1';

// Build SQL Filter
$where = ["1=1"];
$params = [];
$period_text = "Semua Riwayat Transaksi";

switch ($period_scheme) {
    case 'daily':
        $where[] = "DATE(sm.created_at) = :daily_date";
        $params['daily_date'] = $date_val;
        $period_text = "Harian (" . date('d F Y', strtotime($date_val)) . ")";
        break;

    case 'weekly':
        $where[] = "DATE(sm.created_at) BETWEEN :w_start AND :w_end";
        $params['w_start'] = $start_date;
        $params['w_end'] = $end_date;
        $period_text = "Mingguan (" . date('d M Y', strtotime($start_date)) . " s/d " . date('d M Y', strtotime($end_date)) . ")";
        break;

    case 'monthly':
        $where[] = "MONTH(sm.created_at) = :m_month AND YEAR(sm.created_at) = :m_year";
        $params['m_month'] = $month;
        $params['m_year'] = $year;
        $month_names = [
            1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April',
            5 => 'Mei', 6 => 'Juni', 7 => 'Juli', 8 => 'Agustus',
            9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember'
        ];
        $period_text = "Bulanan (" . ($month_names[$month] ?? $month) . " " . $year . ")";
        break;

    case 'yearly':
        $where[] = "YEAR(sm.created_at) = :y_year";
        $params['y_year'] = $year;
        $period_text = "Tahunan (Tahun " . $year . ")";
        break;

    default:
        $period_text = "Semua Periode Transaksi";
        break;
}

if ($type === 'IN' || $type === 'OUT') {
    $where[] = "sm.type = :type";
    $params['type'] = $type;
}

$where_sql = implode(' AND ', $where);

// Fetch Laporan Data
$sql = "SELECT sm.*, p.name AS product_name, p.sku, c.name AS category_name, u.full_name AS user_name 
        FROM stock_movements sm 
        JOIN products p ON p.id = sm.product_id 
        JOIN categories c ON c.id = p.category_id 
        JOIN users u ON u.id = sm.user_id 
        WHERE $where_sql 
        ORDER BY sm.created_at ASC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$movements = $stmt->fetchAll();

// Hitung Rekapitulasi
$total_in = 0;
$total_out = 0;
foreach ($movements as $m) {
    if ($m['type'] === 'IN') {
        $total_in += (int)$m['quantity'];
    } else {
        $total_out += (int)$m['quantity'];
    }
}
$net_flow = $total_in - $total_out;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak Laporan Mutasi Stok - <?= e($period_text) ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; }
        @media print {
            .no-print { display: none !important; }
            body { padding: 0; margin: 0; background: white; }
            .print-container { max-width: 100% !important; border: none !important; box-shadow: none !important; }
            @page { margin: 1.5cm; }
        }
    </style>
</head>
<body class="bg-slate-100 text-slate-800 p-4 sm:p-8">

    <!-- Action Toolbar (Hidden when printing) -->
    <div class="max-w-4xl mx-auto mb-6 flex items-center justify-between no-print">
        <a href="history.php" class="bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 px-4 py-2 rounded-xl text-xs font-semibold transition flex items-center gap-2 shadow-xs">
            <i class="fa-solid fa-arrow-left"></i> Kembali ke Histori Stok
        </a>
        <div class="flex items-center gap-2">
            <button onclick="window.print()" class="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-xl text-xs font-semibold transition flex items-center gap-2 shadow-md shadow-blue-500/25">
                <i class="fa-solid fa-print"></i> Cetak / Simpan PDF
            </button>
        </div>
    </div>

    <!-- Paper Sheet Container -->
    <div class="print-container max-w-4xl mx-auto bg-white p-8 sm:p-12 rounded-3xl border border-slate-200/80 shadow-lg">
        <!-- Official Header / Kop Laporan -->
        <div class="border-b-2 border-slate-900 pb-5 mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
                <div class="flex items-center gap-2.5 mb-1">
                    <span class="bg-slate-900 text-white p-2 rounded-lg text-sm"><i class="fa-solid fa-boxes-packing"></i></span>
                    <h1 class="text-xl font-extrabold text-slate-900 tracking-wider">INVENTORY<span class="text-blue-600">PRO</span></h1>
                </div>
                <p class="text-xs text-slate-500 font-medium">Sistem Manajemen Persediaan Elektronik &bull; Laporan Resmi Pergudangan</p>
            </div>
            <div class="text-left sm:text-right text-xs text-slate-600">
                <p class="font-bold text-slate-900 uppercase tracking-wider text-[11px]">Dokumen Laporan Mutasi</p>
                <p class="mt-0.5">Tanggal Cetak: <span class="font-semibold text-slate-800"><?= date('d/m/Y H:i') ?> WIB</span></p>
                <p>Dicetak Oleh: <span class="font-semibold text-slate-800"><?= e($admin['full_name']) ?> (Admin)</span></p>
            </div>
        </div>

        <!-- Title & Period Metadata -->
        <div class="mb-6 bg-slate-50 p-4 rounded-2xl border border-slate-200/70 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
                <span class="text-[10px] uppercase font-bold tracking-wider text-slate-400 block">Skema Laporan</span>
                <h2 class="text-lg font-extrabold text-slate-900"><?= e($period_text) ?></h2>
                <p class="text-xs text-slate-500 mt-0.5">Jenis Filter: <span class="font-semibold text-slate-700"><?= $type === 'ALL' ? 'Semua Mutasi (Masuk & Keluar)' : ($type === 'IN' ? 'Barang Masuk Saja' : 'Barang Keluar Saja') ?></span></p>
            </div>
            <div class="text-xs bg-white px-3.5 py-2 rounded-xl border border-slate-200/80 text-slate-600 font-semibold shadow-xs">
                Total Transaksi: <span class="text-blue-600 font-bold"><?= count($movements) ?> kali</span>
            </div>
        </div>

        <!-- Summary Statistics Grid -->
        <div class="grid grid-cols-3 gap-3 mb-6">
            <div class="border border-indigo-200 bg-indigo-50/50 p-3 rounded-xl text-center">
                <span class="text-[10px] uppercase font-bold tracking-wider text-indigo-700 block">Total Barang Masuk</span>
                <span class="text-xl font-black text-indigo-900">+<?= number_format($total_in) ?></span>
                <span class="text-[10px] text-slate-500 block">Unit Fisik</span>
            </div>
            <div class="border border-amber-200 bg-amber-50/50 p-3 rounded-xl text-center">
                <span class="text-[10px] uppercase font-bold tracking-wider text-amber-700 block">Total Barang Keluar</span>
                <span class="text-xl font-black text-amber-900">-<?= number_format($total_out) ?></span>
                <span class="text-[10px] text-slate-500 block">Unit Fisik</span>
            </div>
            <div class="border border-slate-200 bg-slate-50/80 p-3 rounded-xl text-center">
                <span class="text-[10px] uppercase font-bold tracking-wider text-slate-600 block">Arus Bersih (Net Flow)</span>
                <span class="text-xl font-black <?= $net_flow >= 0 ? 'text-emerald-700' : 'text-rose-700' ?>">
                    <?= $net_flow >= 0 ? '+' : '' ?><?= number_format($net_flow) ?>
                </span>
                <span class="text-[10px] text-slate-500 block">Unit Bersih</span>
            </div>
        </div>

        <!-- Table Data -->
        <div class="overflow-x-auto border border-slate-200 rounded-xl mb-8">
            <table class="w-full text-left text-xs text-slate-700">
                <thead class="bg-slate-100 border-b border-slate-200 font-bold text-slate-800 uppercase text-[10px] tracking-wider">
                    <tr>
                        <th class="p-3 text-center w-10">No</th>
                        <th class="p-3">Waktu</th>
                        <th class="p-3">Kode SKU</th>
                        <th class="p-3">Nama Produk Elektronik</th>
                        <th class="p-3">Kategori</th>
                        <th class="p-3 text-center">Tipe</th>
                        <th class="p-3 text-right">Volume</th>
                        <th class="p-3">Petugas</th>
                        <th class="p-3">Keterangan</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <?php if (empty($movements)): ?>
                        <tr>
                            <td colspan="9" class="p-8 text-center text-slate-400">
                                Tidak ada data histori transaksi untuk skema periode ini.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php $no = 1; foreach ($movements as $m): ?>
                            <tr class="hover:bg-slate-50/50">
                                <td class="p-3 text-center font-bold text-slate-500"><?= $no++ ?></td>
                                <td class="p-3 text-slate-600 whitespace-nowrap"><?= date('d/m/Y H:i', strtotime($m['created_at'])) ?></td>
                                <td class="p-3 font-mono font-bold text-slate-800"><?= e($m['sku']) ?></td>
                                <td class="p-3 font-semibold text-slate-900"><?= e($m['product_name']) ?></td>
                                <td class="p-3 text-slate-600"><?= e($m['category_name']) ?></td>
                                <td class="p-3 text-center">
                                    <span class="px-2 py-0.5 rounded text-[10px] font-bold <?= $m['type'] === 'IN' ? 'bg-indigo-100 text-indigo-800' : 'bg-amber-100 text-amber-800' ?>">
                                        <?= $m['type'] === 'IN' ? 'MASUK' : 'KELUAR' ?>
                                    </span>
                                </td>
                                <td class="p-3 text-right font-bold <?= $m['type'] === 'IN' ? 'text-indigo-700' : 'text-amber-700' ?>">
                                    <?= $m['type'] === 'IN' ? '+' : '-' ?><?= number_format($m['quantity']) ?>
                                </td>
                                <td class="p-3 text-slate-700"><?= e($m['user_name']) ?></td>
                                <td class="p-3 text-slate-500 text-[11px]"><?= e($m['notes'] ?: '-') ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Official Signatures -->
        <div class="pt-6 border-t border-slate-200 grid grid-cols-2 gap-8 text-xs text-center">
            <div>
                <p class="text-slate-500 mb-16">Mengetahui,<br><span class="font-bold text-slate-800">Kepala Bagian Logistik & Gudang</span></p>
                <p class="font-bold text-slate-900 border-t border-slate-300 pt-1 inline-block min-w-[180px]">( ........................................ )</p>
            </div>
            <div>
                <p class="text-slate-500 mb-16">Dibuat Oleh,<br><span class="font-bold text-slate-800">Administrator Sistem Persediaan</span></p>
                <p class="font-bold text-slate-900 border-t border-slate-300 pt-1 inline-block min-w-[180px]">( <?= e($admin['full_name']) ?> )</p>
            </div>
        </div>
    </div>

    <?php if ($auto_print): ?>
        <script>
            window.addEventListener('DOMContentLoaded', () => {
                setTimeout(() => { window.print(); }, 500);
            });
        </script>
    <?php endif; ?>
</body>
</html>
