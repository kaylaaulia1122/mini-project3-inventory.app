<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../helpers/auth.php';
require_once __DIR__ . '/../../helpers/escape.php';
require_once __DIR__ . '/../../helpers/validation.php';

require_role('admin');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $id = validate_positive_int($_POST['id'] ?? null);

    if ($id) {
        try {
            $pdo->beginTransaction();

            // 1. Bersihkan riwayat movements dan product_suppliers terkait produk ini
            $stmt1 = $pdo->prepare("DELETE FROM stock_movements WHERE product_id = :id");
            $stmt1->execute(['id' => $id]);

            $stmt2 = $pdo->prepare("DELETE FROM product_suppliers WHERE product_id = :id");
            $stmt2->execute(['id' => $id]);

            // 2. Hapus produk
            $stmt3 = $pdo->prepare("DELETE FROM products WHERE id = :id");
            $stmt3->execute(['id' => $id]);

            $pdo->commit();

            $_SESSION['flash_message'] = [
                'type' => 'success',
                'text' => 'Produk berhasil dihapus beserta riwayat mutasinya.'
            ];
        } catch (Throwable $e) {
            $pdo->rollBack();
            $_SESSION['flash_message'] = [
                'type' => 'error',
                'text' => 'Gagal menghapus produk: ' . $e->getMessage()
            ];
        }
    }
}

header("Location: index.php");
exit;
