<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../views/header.php';

$current_role = current_user()['role'];
$is_admin = ($current_role === 'admin');

// Parameter GET untuk Search, Filter, Status Stok, Sorting & Pagination
$q = trim($_GET['q'] ?? '');
$category_id = filter_input(INPUT_GET, 'category_id', FILTER_VALIDATE_INT);
$stock_status = trim($_GET['stock_status'] ?? '');
$page = max(1, (int)($_GET['page'] ?? 1));
$per_page = 8;
$offset = ($page - 1) * $per_page;

// Allowlist Sorting demi Keamanan SQL Injection
$allowed_sorts = [
    'name'  => 'p.name',
    'price' => 'p.price',
    'stock' => 'p.stock',
    'sku'   => 'p.sku'
];
$sort_key = $_GET['sort'] ?? 'name';
$sort_column = $allowed_sorts[$sort_key] ?? 'p.name';

// Build SQL Query
$where_clauses = ["1=1"];
$params = [];

if ($q !== '') {
    $where_clauses[] = "(p.name LIKE :q OR p.sku LIKE :q)";
    $params['q'] = "%$q%";
}
if ($category_id) {
    $where_clauses[] = "p.category_id = :category_id";
    $params['category_id'] = $category_id;
}
if ($stock_status === 'low') {
    $where_clauses[] = "p.stock <= p.minimum_stock";
} elseif ($stock_status === 'empty') {
    $where_clauses[] = "p.stock = 0";
} elseif ($stock_status === 'safe') {
    $where_clauses[] = "p.stock > p.minimum_stock";
}

$where_sql = implode(' AND ', $where_clauses);

// Hitung Total Data untuk Pagination
$count_stmt = $pdo->prepare("SELECT COUNT(*) FROM products p WHERE $where_sql");
$count_stmt->execute($params);
$total_rows = $count_stmt->fetchColumn();
$total_pages = ceil($total_rows / $per_page);

// Fetch Main Data
$sql = "SELECT p.*, c.name AS category_name 
        FROM products p 
        JOIN categories c ON c.id = p.category_id 
        WHERE $where_sql 
        ORDER BY $sort_column ASC 
        LIMIT :limit OFFSET :offset";

$stmt = $pdo->prepare($sql);
foreach ($params as $key => $val) {
    $stmt->bindValue(":$key", $val);
}
$stmt->bindValue(':limit', $per_page, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$products = $stmt->fetchAll();

$categories = $pdo->query("SELECT * FROM categories ORDER BY name ASC")->fetchAll();

// Handle Flash Message
$flash = $_SESSION['flash_message'] ?? null;
unset($_SESSION['flash_message']);
?>

<div class="space-y-6">
    <!-- Top Header -->
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
            <h2 class="text-2xl font-extrabold text-slate-900 tracking-tight">Master Data Produk</h2>
            <p class="text-xs text-slate-500 mt-1">Katalog persediaan produk elektronik toko dan status stok fisik</p>
        </div>
        <?php if ($is_admin): ?>
            <a href="create.php" class="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white px-4 py-2.5 rounded-xl text-xs font-semibold shadow-md shadow-blue-500/25 transition flex items-center gap-2 w-fit">
                <i class="fa-solid fa-plus"></i> Tambah Produk Baru
            </a>
        <?php endif; ?>
    </div>

    <!-- Flash Alert Message -->
    <?php if ($flash): ?>
        <div class="p-4 rounded-2xl flex items-center gap-3 border <?= $flash['type'] === 'success' ? 'bg-emerald-50 border-emerald-200 text-emerald-800' : 'bg-rose-50 border-rose-200 text-rose-800' ?>">
            <i class="fa-solid <?= $flash['type'] === 'success' ? 'fa-circle-check text-emerald-600' : 'fa-circle-exclamation text-rose-600' ?> text-lg"></i>
            <span class="text-sm font-semibold"><?= e($flash['text']) ?></span>
        </div>
    <?php endif; ?>

    <!-- Search & Filter Controls -->
    <div class="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-sm space-y-4">
        <form method="GET" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <!-- Search input -->
            <div class="relative">
                <span class="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                    <i class="fa-solid fa-magnifying-glass text-xs"></i>
                </span>
                <input type="text" name="q" value="<?= e($q) ?>" placeholder="Cari Nama / Kode SKU..." class="w-full pl-9 pr-4 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-slate-50/50 focus:bg-white transition">
            </div>

            <!-- Category filter dropdown -->
            <div>
                <select name="category_id" class="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm bg-white focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option value="">Semua Kategori (5 Kategori)</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?= $cat['id'] ?>" <?= $category_id == $cat['id'] ? 'selected' : '' ?>>
                            <?= e($cat['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Stock status filter dropdown -->
            <div>
                <select name="stock_status" class="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm bg-white focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option value="" <?= $stock_status === '' ? 'selected' : '' ?>>Semua Status Stok</option>
                    <option value="low" <?= $stock_status === 'low' ? 'selected' : '' ?>>⚠️ Stok Kritis (&le; Minimum)</option>
                    <option value="empty" <?= $stock_status === 'empty' ? 'selected' : '' ?>>❌ Stok Habis (0 Unit)</option>
                    <option value="safe" <?= $stock_status === 'safe' ? 'selected' : '' ?>>✅ Stok Aman (> Minimum)</option>
                </select>
            </div>

            <!-- Action buttons: Filter & Reset -->
            <div class="flex items-center gap-2">
                <button type="submit" class="flex-1 bg-slate-800 hover:bg-slate-900 text-white px-4 py-2.5 rounded-xl text-xs font-semibold transition flex items-center justify-center gap-2">
                    <i class="fa-solid fa-filter text-xs"></i> Filter Data
                </button>
                <?php if ($q !== '' || $category_id || $stock_status !== ''): ?>
                    <a href="index.php" title="Hapus semua filter" class="bg-slate-100 hover:bg-slate-200 text-slate-600 px-3 py-2.5 rounded-xl text-xs font-semibold transition flex items-center justify-center gap-1.5">
                        <i class="fa-solid fa-rotate-left"></i> Reset
                    </a>
                <?php endif; ?>
            </div>
        </form>

        <!-- Penjelasan / Info Fungsi Filter (Sesuai Pertanyaan No. 5) -->
        <div class="pt-3 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between text-xs text-slate-500 gap-2">
            <div class="flex items-center gap-1.5 text-slate-500">
                <i class="fa-solid fa-circle-question text-blue-500"></i>
                <span><b>Fungsi Filter:</b> Menyaring data produk berdasarkan kata kunci pencarian, kategori elektronik, dan peringatan batas stok fisik.</span>
            </div>
            <div class="font-medium text-slate-700">
                Menampilkan <b><?= count($products) ?></b> dari <b><?= $total_rows ?></b> total produk
            </div>
        </div>
    </div>

    <!-- Products Table -->
    <div class="bg-white rounded-2xl border border-slate-200/80 shadow-sm overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-left text-sm text-slate-600">
                <thead class="bg-slate-50/80 border-b border-slate-200 font-bold text-slate-700 uppercase text-[11px] tracking-wider">
                    <tr>
                        <th class="p-4">SKU</th>
                        <th class="p-4">Nama Produk Elektronik</th>
                        <th class="p-4">Kategori</th>
                        <th class="p-4">Harga Satuan</th>
                        <th class="p-4">Status & Sisa Stok</th>
                        <?php if ($is_admin): ?>
                            <th class="p-4 text-center">Aksi (Admin)</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <?php if (empty($products)): ?>
                        <tr>
                            <td colspan="<?= $is_admin ? 6 : 5 ?>" class="p-8 text-center text-slate-400">
                                <i class="fa-solid fa-box-open text-3xl mb-2 block"></i>
                                Tidak ditemukan produk yang sesuai dengan kriteria filter.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($products as $p): ?>
                            <?php 
                            $is_critical = ($p['stock'] <= $p['minimum_stock']);
                            $is_empty = ($p['stock'] <= 0);
                            ?>
                            <tr class="hover:bg-slate-50/70 transition">
                                <td class="p-4 font-mono font-bold text-xs text-slate-800">
                                    <span class="bg-slate-100 px-2 py-1 rounded-md text-slate-700 border border-slate-200">
                                        <?= e($p['sku']) ?>
                                    </span>
                                </td>
                                <td class="p-4">
                                    <span class="font-bold text-slate-900 block"><?= e($p['name']) ?></span>
                                    <span class="text-[11px] text-slate-400">Min. Stok: <?= number_format($p['minimum_stock']) ?> unit</span>
                                </td>
                                <td class="p-4">
                                    <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200/50">
                                        <i class="fa-solid fa-tag text-[10px]"></i>
                                        <?= e($p['category_name']) ?>
                                    </span>
                                </td>
                                <td class="p-4 font-semibold text-slate-900">
                                    Rp <?= number_format($p['price'], 0, ',', '.') ?>
                                </td>
                                <td class="p-4">
                                    <div class="flex items-center gap-2">
                                        <span class="px-2.5 py-1 rounded-full text-xs font-bold inline-flex items-center gap-1.5 <?= $is_empty ? 'bg-rose-100 text-rose-800' : ($is_critical ? 'bg-amber-100 text-amber-800' : 'bg-emerald-100 text-emerald-800') ?>">
                                            <span class="w-1.5 h-1.5 rounded-full <?= $is_empty ? 'bg-rose-600' : ($is_critical ? 'bg-amber-600' : 'bg-emerald-600') ?>"></span>
                                            <?= number_format($p['stock']) ?> unit
                                        </span>
                                        <?php if ($is_critical): ?>
                                            <span class="text-[10px] font-bold text-rose-600 uppercase">Kritis</span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <?php if ($is_admin): ?>
                                    <td class="p-4">
                                        <div class="flex items-center justify-center gap-2">
                                            <!-- Tombol Edit -->
                                            <a href="edit.php?id=<?= $p['id'] ?>" class="bg-blue-50 hover:bg-blue-100 text-blue-600 px-3 py-1.5 rounded-lg text-xs font-semibold transition flex items-center gap-1.5 border border-blue-200/60">
                                                <i class="fa-solid fa-pen-to-square"></i> Edit
                                            </a>

                                            <!-- Tombol Hapus (Fitur Hapus Produk Sesuai Request No. 4) -->
                                            <form method="POST" action="delete.php" onsubmit="return confirm('Apakah Anda yakin ingin menghapus produk [<?= e($p['name']) ?>]? Semua riwayat stok terkait juga akan dibersihkan.');" class="inline">
                                                <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                                                <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
                                                <button type="submit" class="bg-rose-50 hover:bg-rose-100 text-rose-600 px-3 py-1.5 rounded-lg text-xs font-semibold transition flex items-center gap-1.5 border border-rose-200/60">
                                                    <i class="fa-solid fa-trash-can"></i> Hapus
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Pagination Links -->
    <?php if ($total_pages > 1): ?>
        <div class="flex justify-center items-center gap-1.5">
            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <a href="?page=<?= $i ?>&q=<?= urlencode($q) ?>&category_id=<?= (int)$category_id ?>&stock_status=<?= urlencode($stock_status) ?>&sort=<?= urlencode($sort_key) ?>" 
                   class="px-3.5 py-2 rounded-xl text-xs font-bold border transition <?= $i === $page ? 'bg-blue-600 border-blue-600 text-white shadow-sm shadow-blue-500/30' : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50' ?>">
                    <?= $i ?>
                </a>
            <?php endfor; ?>
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../../views/footer.php'; ?>