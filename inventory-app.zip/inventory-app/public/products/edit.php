<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../helpers/validation.php';
require_once __DIR__ . '/../../views/header.php';

require_role('admin');

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id) { 
    header("Location: index.php"); 
    exit; 
}

$stmt = $pdo->prepare("SELECT * FROM products WHERE id = :id");
$stmt->execute(['id' => $id]);
$product = $stmt->fetch();
if (!$product) { 
    header("Location: index.php"); 
    exit; 
}

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $sku = sanitize_input($_POST['sku'] ?? '');
    $name = sanitize_input($_POST['name'] ?? '');
    $category_id = validate_positive_int($_POST['category_id'] ?? null);
    $price = filter_input(INPUT_POST, 'price', FILTER_VALIDATE_FLOAT);
    $min_stock = validate_non_negative_int($_POST['minimum_stock'] ?? null);

    if (!$sku) $errors[] = 'SKU produk wajib diisi.';
    if (!$name) $errors[] = 'Nama produk wajib diisi.';
    if (!$category_id) $errors[] = 'Pilih kategori elektronik yang valid.';
    if ($price === false || $price <= 0) $errors[] = 'Harga satuan harus bernilai positif.';
    if ($min_stock === false) $errors[] = 'Stok minimum harus berupa angka 0 atau lebih.';

    if (empty($errors)) {
        try {
            $update = $pdo->prepare("
                UPDATE products 
                SET sku = :sku, name = :name, category_id = :category_id, price = :price, minimum_stock = :min_stock 
                WHERE id = :id
            ");
            $update->execute([
                'sku'         => $sku,
                'name'        => $name,
                'category_id' => $category_id,
                'price'       => $price,
                'min_stock'   => $min_stock,
                'id'          => $id
            ]);

            $_SESSION['flash_message'] = [
                'type' => 'success',
                'text' => 'Data produk "' . $name . '" berhasil diperbarui.'
            ];

            header("Location: index.php");
            exit;
        } catch (PDOException $e) {
            $errors[] = 'Gagal menyimpan: Kode SKU mungkin sudah digunakan produk lain.';
        }
    }
}

$categories = $pdo->query("SELECT * FROM categories ORDER BY name ASC")->fetchAll();
?>

<div class="max-w-xl mx-auto space-y-6">
    <div class="flex items-center justify-between">
        <a href="index.php" class="text-xs font-semibold text-slate-500 hover:text-slate-800 flex items-center gap-1.5 transition">
            <i class="fa-solid fa-arrow-left"></i> Kembali ke Master Produk
        </a>
        <span class="text-xs font-mono bg-slate-100 text-slate-600 px-2.5 py-1 rounded-md border border-slate-200">ID: #<?= (int)$id ?></span>
    </div>

    <div class="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200/80 shadow-sm">
        <div class="flex items-center gap-3 pb-5 mb-6 border-b border-slate-100">
            <div class="w-11 h-11 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center text-lg">
                <i class="fa-solid fa-pen-to-square"></i>
            </div>
            <div>
                <h2 class="text-xl font-bold text-slate-900">Edit Data Produk</h2>
                <p class="text-xs text-slate-400">Perbarui spesifikasi produk dan batas ketersediaan stok</p>
            </div>
        </div>

        <?php if (!empty($errors)): ?>
            <div class="bg-rose-50 border border-rose-200 text-rose-700 text-xs p-3.5 rounded-2xl mb-6 space-y-1">
                <?php foreach ($errors as $err): ?>
                    <p><i class="fa-solid fa-circle-exclamation mr-1"></i> <?= e($err) ?></p>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <form method="POST" class="space-y-4">
            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <label class="block text-xs uppercase font-bold text-slate-600 mb-1.5">Kode SKU *</label>
                    <input type="text" name="sku" value="<?= e($_POST['sku'] ?? $product['sku']) ?>" required class="w-full font-mono border border-slate-200 p-2.5 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-slate-50 focus:bg-white transition">
                </div>
                <div>
                    <label class="block text-xs uppercase font-bold text-slate-600 mb-1.5">Kategori Elektronik *</label>
                    <select name="category_id" required class="w-full border border-slate-200 p-2.5 rounded-xl text-sm bg-white focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?= $cat['id'] ?>" <?= ($cat['id'] == ($_POST['category_id'] ?? $product['category_id'])) ? 'selected' : '' ?>>
                                <?= e($cat['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div>
                <label class="block text-xs uppercase font-bold text-slate-600 mb-1.5">Nama Produk Elektronik *</label>
                <input type="text" name="name" value="<?= e($_POST['name'] ?? $product['name']) ?>" required class="w-full border border-slate-200 p-2.5 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-slate-50 focus:bg-white transition">
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <label class="block text-xs uppercase font-bold text-slate-600 mb-1.5">Harga Jual Satuan (Rp) *</label>
                    <input type="number" step="0.01" name="price" value="<?= e($_POST['price'] ?? $product['price']) ?>" required class="w-full border border-slate-200 p-2.5 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-slate-50 focus:bg-white transition">
                </div>
                <div>
                    <label class="block text-xs uppercase font-bold text-slate-600 mb-1.5">Batas Minimum Stok *</label>
                    <input type="number" name="minimum_stock" value="<?= e($_POST['minimum_stock'] ?? $product['minimum_stock']) ?>" required class="w-full border border-slate-200 p-2.5 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-slate-50 focus:bg-white transition">
                </div>
            </div>

            <div class="pt-4 flex items-center gap-3">
                <a href="index.php" class="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold py-2.5 rounded-xl text-xs text-center transition">
                    Batal
                </a>
                <button type="submit" class="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2.5 rounded-xl text-xs shadow-md shadow-blue-500/25 transition">
                    Simpan Perubahan
                </button>
            </div>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/../../views/footer.php'; ?>