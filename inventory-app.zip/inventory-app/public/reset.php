<?php
// public/reset.php
require_once __DIR__ . '/../config/database.php';

// Generate hash resmi untuk admin (admin123) dan staff (staff123)
$admin_hash = password_hash('admin123', PASSWORD_DEFAULT);
$staff_hash = password_hash('staff123', PASSWORD_DEFAULT);

$stmt1 = $pdo->prepare("UPDATE users SET password_hash = :hash WHERE username = 'admin'");
$stmt1->execute(['hash' => $admin_hash]);

$stmt2 = $pdo->prepare("UPDATE users SET password_hash = :hash WHERE username = 'staff'");
$stmt2->execute(['hash' => $staff_hash]);

echo "<h2 style='color:green; font-family:sans-serif;'>✅ Password berhasil di-reset!</h2>";
echo "<p style='font-family:sans-serif;'>Password <b>admin</b>: <code>admin123</code><br>Password <b>staff</b>: <code>staff123</code></p>";
echo "<a style='font-family:sans-serif;' href='login.php'>Klik di sini untuk Login</a>";