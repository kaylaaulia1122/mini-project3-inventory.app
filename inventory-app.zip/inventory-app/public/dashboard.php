<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../views/header.php';

$user = current_user();
$is_admin = ($user['role'] === 'admin');

// 1. Agregat Utama
$total_products = (int)$pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
$low_stock = (int)$pdo->query("SELECT COUNT(*) FROM products WHERE stock <= minimum_stock")->fetchColumn();
$total_in = (int)($pdo->query("SELECT SUM(quantity) FROM stock_movements WHERE type = 'IN'")->fetchColumn() ?? 0);
$total_out = (int)($pdo->query("SELECT SUM(quantity) FROM stock_movements WHERE type = 'OUT'")->fetchColumn() ?? 0);
$total_transactions = (int)$pdo->query("SELECT COUNT(*) FROM stock_movements")->fetchColumn();

// Nilai inventaris HANYA dihitung dan diakses jika user adalah ADMIN (Rahasia Admin)
$total_val = 0;
if ($is_admin) {
    $total_val = (float)($pdo->query("SELECT SUM(stock * price) FROM products")->fetchColumn() ?? 0);
}

// 2. Data Diagram Arus Barang (7 Hari Terakhir)
$chart_days = [];
for ($i = 6; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime("-$i days"));
    $chart_days[$d] = [
        'label' => date('d M', strtotime($d)),
        'in'    => 0,
        'out'   => 0
    ];
}

$stmt_chart = $pdo->prepare("
    SELECT DATE(created_at) as m_date, type, SUM(quantity) as total_qty 
    FROM stock_movements 
    WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
    GROUP BY DATE(created_at), type
");
$stmt_chart->execute();
while ($row = $stmt_chart->fetch()) {
    $m_date = $row['m_date'];
    if (isset($chart_days[$m_date])) {
        if ($row['type'] === 'IN') {
            $chart_days[$m_date]['in'] = (int)$row['total_qty'];
        } else {
            $chart_days[$m_date]['out'] = (int)$row['total_qty'];
        }
    }
}

$chart_labels = array_column(array_values($chart_days), 'label');
$chart_in_data = array_column(array_values($chart_days), 'in');
$chart_out_data = array_column(array_values($chart_days), 'out');

// 3. Mutasi Terkini (5 Transaksi Terakhir)
$recent_movements = $pdo->query("
    SELECT sm.*, p.name AS product_name, p.sku, u.full_name AS user_name, u.role AS user_role
    FROM stock_movements sm
    JOIN products p ON p.id = sm.product_id
    JOIN users u ON u.id = sm.user_id
    ORDER BY sm.created_at DESC
    LIMIT 5
")->fetchAll();

// 4. Produk Stok Kritis
$critical_products = $pdo->query("
    SELECT p.*, c.name AS category_name
    FROM products p
    JOIN categories c ON c.id = p.category_id
    WHERE p.stock <= p.minimum_stock
    ORDER BY p.stock ASC
    LIMIT 5
")->fetchAll();

// 5. Khusus Admin: Ringkasan per Kategori (5 Kategori Elektronik)
$category_summary = [];
if ($is_admin) {
    $category_summary = $pdo->query("
        SELECT c.id, c.name, 
               COUNT(p.id) AS total_items, 
               COALESCE(SUM(p.stock), 0) AS total_stock,
               COALESCE(SUM(p.stock * p.price), 0) AS total_valuation
        FROM categories c
        LEFT JOIN products p ON p.category_id = c.id
        GROUP BY c.id, c.name
        ORDER BY total_items DESC, c.name ASC
    ")->fetchAll();
}
?>

<div class="space-y-6">
    <!-- Header Banner dengan perbedaan Role Admin vs Staff -->
    <div class="relative overflow-hidden rounded-3xl p-6 md:p-8 text-white shadow-xl <?= $is_admin ? 'bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-indigo-900/40' : 'bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 border border-emerald-900/40' ?>">
        <div class="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
            <div>
                <div class="flex items-center gap-2 mb-2">
                    <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider <?= $is_admin ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-400/30' : 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/30' ?>">
                        <i class="fa-solid <?= $is_admin ? 'fa-shield-halved' : 'fa-clipboard-check' ?>"></i>
                        <?= $is_admin ? 'Dashboard Administrator' : 'Portal Operasional Staff Gudang' ?>
                    </span>
                    <span class="text-xs text-slate-400">| <?= date('l, d F Y') ?></span>
                </div>
                <h1 class="text-2xl md:text-3xl font-extrabold tracking-tight text-white">
                    Selamat Datang, <?= e($user['full_name']) ?>! 👋
                </h1>
                <p class="text-sm text-slate-300 mt-1 max-w-2xl leading-relaxed">
                    <?= $is_admin 
                        ? 'Pantau pergerakan arus barang, valuasi total aset persediaan, dan kelola katalog produk elektronik toko Anda.' 
                        : 'Kelola alur pencatatan barang masuk dan barang keluar, serta pantau persediaan fisik di gudang secara real-time.' ?>
                </p>
            </div>

            <!-- Quick Action Buttons -->
            <div class="flex flex-wrap items-center gap-2.5">
                <?php if ($is_admin): ?>
                    <a href="/inventory-app/public/products/create.php" class="bg-blue-600 hover:bg-blue-500 text-white px-4 py-2.5 rounded-xl text-xs font-semibold shadow-md shadow-blue-600/30 transition flex items-center gap-2">
                        <i class="fa-solid fa-plus"></i> Tambah Produk
                    </a>
                    <a href="/inventory-app/public/stock/history.php" class="bg-slate-800/90 hover:bg-slate-700 text-slate-200 px-4 py-2.5 rounded-xl text-xs font-semibold border border-slate-700 shadow-sm transition flex items-center gap-2">
                        <i class="fa-solid fa-print"></i> Cetak Laporan
                    </a>
                <?php endif; ?>
                <a href="/inventory-app/public/stock/in.php" class="bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-2.5 rounded-xl text-xs font-semibold shadow-md shadow-indigo-600/30 transition flex items-center gap-2">
                    <i class="fa-solid fa-circle-arrow-down"></i> Catat Masuk
                </a>
                <a href="/inventory-app/public/stock/out.php" class="bg-amber-600 hover:bg-amber-500 text-white px-4 py-2.5 rounded-xl text-xs font-semibold shadow-md shadow-amber-600/30 transition flex items-center gap-2">
                    <i class="fa-solid fa-circle-arrow-up"></i> Catat Keluar
                </a>
            </div>
        </div>
    </div>

    <!-- Stat Cards Grid -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <!-- Card 1: Total Produk (Both Admin & Staff) -->
        <div class="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-sm hover:shadow-md transition group">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-xs font-bold uppercase tracking-wider text-slate-400">Total Jenis Produk</p>
                    <h3 class="text-2xl font-black text-slate-900 mt-1"><?= number_format($total_products) ?></h3>
                    <p class="text-[11px] text-slate-500 mt-1 flex items-center gap-1">
                        <i class="fa-solid fa-microchip text-blue-500"></i> Katalog Elektronik
                    </p>
                </div>
                <div class="w-12 h-12 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center text-xl group-hover:scale-110 transition">
                    <i class="fa-solid fa-boxes-stacked"></i>
                </div>
            </div>
        </div>

        <?php if ($is_admin): ?>
            <!-- Card 2 ADMIN: Nilai Inventaris (RAHASIA ADMIN - Hanya tampil di admin) -->
            <div class="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-sm hover:shadow-md transition group">
                <div class="flex items-center justify-between">
                    <div>
                        <div class="flex items-center gap-1.5">
                            <p class="text-xs font-bold uppercase tracking-wider text-slate-400">Nilai Inventaris</p>
                            <span class="text-[9px] px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800 font-bold">Admin Only</span>
                        </div>
                        <h3 class="text-xl md:text-2xl font-black text-slate-900 mt-1">Rp <?= number_format($total_val, 0, ',', '.') ?></h3>
                        <p class="text-[11px] text-emerald-600 font-medium mt-1 flex items-center gap-1">
                            <i class="fa-solid fa-lock text-emerald-500"></i> Total Nilai Aset Fisik
                        </p>
                    </div>
                    <div class="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center text-xl group-hover:scale-110 transition">
                        <i class="fa-solid fa-vault"></i>
                    </div>
                </div>
            </div>

            <!-- Card 3 ADMIN: Ringkasan Total Arus Masuk & Keluar -->
            <div class="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-sm hover:shadow-md transition group">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-xs font-bold uppercase tracking-wider text-slate-400">Total Arus Barang</p>
                        <div class="flex items-center gap-3 mt-1">
                            <div>
                                <span class="text-xs font-bold text-indigo-600">+<?= number_format($total_in) ?></span>
                                <span class="text-[10px] text-slate-400 block">Masuk</span>
                            </div>
                            <span class="text-slate-300">/</span>
                            <div>
                                <span class="text-xs font-bold text-amber-600">-<?= number_format($total_out) ?></span>
                                <span class="text-[10px] text-slate-400 block">Keluar</span>
                            </div>
                        </div>
                        <p class="text-[11px] text-slate-500 mt-1"><?= number_format($total_transactions) ?> transaksi tercatat</p>
                    </div>
                    <div class="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center text-xl group-hover:scale-110 transition">
                        <i class="fa-solid fa-arrow-right-arrow-left"></i>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <!-- Card 2 STAFF: Total Barang Masuk (MENGGANTIKAN NILAI INVENTARIS) -->
            <div class="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-sm hover:shadow-md transition group">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-xs font-bold uppercase tracking-wider text-slate-400">Total Barang Masuk</p>
                        <h3 class="text-2xl font-black text-indigo-600 mt-1"><?= number_format($total_in) ?> <span class="text-sm font-semibold text-slate-500">unit</span></h3>
                        <p class="text-[11px] text-slate-500 mt-1 flex items-center gap-1">
                            <i class="fa-solid fa-arrow-down text-indigo-500"></i> Akumulasi Penerimaan
                        </p>
                    </div>
                    <div class="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center text-xl group-hover:scale-110 transition">
                        <i class="fa-solid fa-circle-arrow-down"></i>
                    </div>
                </div>
            </div>

            <!-- Card 3 STAFF: Total Barang Keluar -->
            <div class="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-sm hover:shadow-md transition group">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-xs font-bold uppercase tracking-wider text-slate-400">Total Barang Keluar</p>
                        <h3 class="text-2xl font-black text-amber-600 mt-1"><?= number_format($total_out) ?> <span class="text-sm font-semibold text-slate-500">unit</span></h3>
                        <p class="text-[11px] text-slate-500 mt-1 flex items-center gap-1">
                            <i class="fa-solid fa-arrow-up text-amber-500"></i> Akumulasi Pengeluaran
                        </p>
                    </div>
                    <div class="w-12 h-12 bg-amber-50 text-amber-600 rounded-2xl flex items-center justify-center text-xl group-hover:scale-110 transition">
                        <i class="fa-solid fa-circle-arrow-up"></i>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <!-- Card 4: Stok Kritis (Both Admin & Staff) -->
        <div class="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-sm hover:shadow-md transition group">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-xs font-bold uppercase tracking-wider text-slate-400">Stok Kritis (&le; Minimum)</p>
                    <h3 class="text-2xl font-black <?= $low_stock > 0 ? 'text-rose-600' : 'text-slate-900' ?> mt-1">
                        <?= number_format($low_stock) ?> <span class="text-sm font-semibold text-slate-500">produk</span>
                    </h3>
                    <p class="text-[11px] <?= $low_stock > 0 ? 'text-rose-600 font-semibold' : 'text-emerald-600' ?> mt-1 flex items-center gap-1">
                        <i class="fa-solid <?= $low_stock > 0 ? 'fa-triangle-exclamation' : 'fa-circle-check' ?>"></i>
                        <?= $low_stock > 0 ? 'Perlu segera restock' : 'Semua stok aman' ?>
                    </p>
                </div>
                <div class="w-12 h-12 <?= $low_stock > 0 ? 'bg-rose-50 text-rose-600' : 'bg-slate-50 text-slate-400' ?> rounded-2xl flex items-center justify-center text-xl group-hover:scale-110 transition">
                    <i class="fa-solid fa-bell"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- DIAGRAM SECTION: Diagram Barang Masuk & Barang Keluar (Ditampilkan untuk Admin & Staff) -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Main Chart: Bar Chart Barang Masuk vs Barang Keluar (7 Hari Terakhir) -->
        <div class="lg:col-span-2 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm flex flex-col justify-between">
            <div>
                <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
                    <div>
                        <div class="flex items-center gap-2">
                            <span class="w-2.5 h-2.5 rounded-full bg-blue-600"></span>
                            <h2 class="text-lg font-bold text-slate-900">Diagram Arus Barang Masuk & Keluar</h2>
                        </div>
                        <p class="text-xs text-slate-500 mt-0.5">Monitoring volume transaksi barang 7 hari terakhir (dalam unit)</p>
                    </div>

                    <!-- Legend Quick Badges -->
                    <div class="flex items-center gap-3">
                        <span class="inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-lg bg-indigo-50 text-indigo-700">
                            <span class="w-2.5 h-2.5 rounded-full bg-indigo-600"></span> Masuk (IN)
                        </span>
                        <span class="inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-lg bg-amber-50 text-amber-700">
                            <span class="w-2.5 h-2.5 rounded-full bg-amber-500"></span> Keluar (OUT)
                        </span>
                    </div>
                </div>

                <div class="h-64 sm:h-72 w-full relative">
                    <canvas id="stockMovementChart"></canvas>
                </div>
            </div>

            <div class="mt-4 pt-4 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                <span><i class="fa-solid fa-clock text-slate-400 mr-1"></i> Data diperbarui otomatis secara real-time.</span>
                <a href="/inventory-app/public/stock/history.php" class="text-blue-600 hover:text-blue-700 font-semibold flex items-center gap-1">
                    Buka Riwayat Lengkap <i class="fa-solid fa-arrow-right text-[10px]"></i>
                </a>
            </div>
        </div>

        <!-- Secondary Chart: Rasio Perbandingan Mutasi & Ringkasan -->
        <div class="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm flex flex-col justify-between">
            <div>
                <h3 class="text-base font-bold text-slate-900 mb-1 flex items-center gap-2">
                    <i class="fa-solid fa-chart-pie text-indigo-600"></i> Rasio Arus Persediaan
                </h3>
                <p class="text-xs text-slate-500 mb-4">Perbandingan total barang masuk vs keluar</p>

                <div class="h-48 relative flex items-center justify-center">
                    <canvas id="ratioDoughnutChart"></canvas>
                </div>

                <!-- Stats summary below doughnut -->
                <div class="grid grid-cols-2 gap-3 mt-4 pt-3 border-t border-slate-100">
                    <div class="bg-indigo-50/70 p-3 rounded-xl text-center">
                        <span class="text-[11px] font-bold uppercase tracking-wider text-indigo-600 block">Barang Masuk</span>
                        <span class="text-lg font-black text-indigo-900"><?= number_format($total_in) ?></span>
                        <span class="text-[10px] text-slate-500 block">unit diterima</span>
                    </div>
                    <div class="bg-amber-50/70 p-3 rounded-xl text-center">
                        <span class="text-[11px] font-bold uppercase tracking-wider text-amber-600 block">Barang Keluar</span>
                        <span class="text-lg font-black text-amber-900"><?= number_format($total_out) ?></span>
                        <span class="text-[10px] text-slate-500 block">unit dikeluarkan</span>
                    </div>
                </div>
            </div>

            <div class="mt-4 text-[11px] text-center text-slate-400">
                Total Mutasi: <b><?= number_format($total_in + $total_out) ?> Unit Fisik</b>
            </div>
        </div>
    </div>

    <!-- DETAIL PANELS SECTION: Sesuai Role Admin vs Staff -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Panel 1: Mutasi Terkini (Admin & Staff) -->
        <div class="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm">
            <div class="flex items-center justify-between mb-4">
                <div>
                    <h3 class="text-base font-bold text-slate-900 flex items-center gap-2">
                        <i class="fa-solid fa-clock-rotate-left text-blue-600"></i> Aktivitas Mutasi Terkini
                    </h3>
                    <p class="text-xs text-slate-500">Log riwayat transaksi barang terbaru</p>
                </div>
                <a href="/inventory-app/public/stock/history.php" class="text-xs font-semibold text-blue-600 hover:text-blue-700">Lihat Semua &rarr;</a>
            </div>

            <?php if (empty($recent_movements)): ?>
                <div class="text-center py-8 text-slate-400 text-sm">
                    <i class="fa-solid fa-inbox text-3xl mb-2 block"></i>
                    Belum ada data pergerakan barang.
                </div>
            <?php else: ?>
                <div class="divide-y divide-slate-100">
                    <?php foreach ($recent_movements as $m): ?>
                        <div class="py-3 flex items-center justify-between gap-3 first:pt-0 last:pb-0">
                            <div class="flex items-center gap-3 min-w-0">
                                <span class="w-9 h-9 rounded-xl flex items-center justify-center shrink-0 <?= $m['type'] === 'IN' ? 'bg-indigo-50 text-indigo-600' : 'bg-amber-50 text-amber-600' ?>">
                                    <i class="fa-solid <?= $m['type'] === 'IN' ? 'fa-arrow-down' : 'fa-arrow-up' ?> text-sm"></i>
                                </span>
                                <div class="min-w-0">
                                    <p class="text-sm font-semibold text-slate-800 truncate"><?= e($m['product_name']) ?></p>
                                    <p class="text-xs text-slate-400 truncate">
                                        <span class="font-mono text-slate-500 font-medium"><?= e($m['sku']) ?></span> &bull; 
                                        Oleh: <span class="font-medium text-slate-600"><?= e($m['user_name']) ?></span>
                                    </p>
                                </div>
                            </div>
                            <div class="text-right shrink-0">
                                <span class="text-sm font-bold <?= $m['type'] === 'IN' ? 'text-indigo-600' : 'text-amber-600' ?>">
                                    <?= $m['type'] === 'IN' ? '+' : '-' ?><?= number_format($m['quantity']) ?> unit
                                </span>
                                <p class="text-[10px] text-slate-400"><?= date('d/m H:i', strtotime($m['created_at'])) ?></p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <?php if ($is_admin): ?>
            <!-- Panel 2 ADMIN: Sebaran Produk per 5 Kategori Elektronik & Valuasi -->
            <div class="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm">
                <div class="flex items-center justify-between mb-4">
                    <div>
                        <h3 class="text-base font-bold text-slate-900 flex items-center gap-2">
                            <i class="fa-solid fa-layer-group text-emerald-600"></i> Sebaran 5 Kategori Elektronik
                        </h3>
                        <p class="text-xs text-slate-500">Distribusi stok dan valuasi per kategori barang</p>
                    </div>
                    <span class="text-xs font-bold text-slate-400"><?= count($category_summary) ?> Kategori</span>
                </div>

                <div class="space-y-3.5">
                    <?php foreach ($category_summary as $cat): ?>
                        <div class="p-3 rounded-xl bg-slate-50/70 border border-slate-100 flex items-center justify-between gap-4">
                            <div class="min-w-0 flex-1">
                                <div class="flex items-center justify-between mb-1">
                                    <span class="text-sm font-bold text-slate-800 truncate"><?= e($cat['name']) ?></span>
                                    <span class="text-xs font-semibold text-slate-600"><?= number_format($cat['total_items']) ?> produk (<?= number_format($cat['total_stock']) ?> unit)</span>
                                </div>
                                <div class="flex items-center justify-between text-xs text-emerald-600 font-medium">
                                    <span>Valuasi:</span>
                                    <span class="font-bold">Rp <?= number_format($cat['total_valuation'], 0, ',', '.') ?></span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php else: ?>
            <!-- Panel 2 STAFF: Daftar Produk Stok Menipis (Peringatan Khusus Gudang) -->
            <div class="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm">
                <div class="flex items-center justify-between mb-4">
                    <div>
                        <h3 class="text-base font-bold text-slate-900 flex items-center gap-2">
                            <i class="fa-solid fa-triangle-exclamation text-rose-500"></i> Perhatian: Stok Menipis
                        </h3>
                        <p class="text-xs text-slate-500">Produk yang mencapai batas minimum penyimpanan</p>
                    </div>
                    <span class="text-xs font-bold px-2 py-0.5 rounded-full <?= $low_stock > 0 ? 'bg-rose-100 text-rose-700' : 'bg-emerald-100 text-emerald-700' ?>">
                        <?= $low_stock ?> item
                    </span>
                </div>

                <?php if (empty($critical_products)): ?>
                    <div class="text-center py-8 text-slate-400 text-sm">
                        <i class="fa-solid fa-circle-check text-emerald-500 text-3xl mb-2 block"></i>
                        Semua stok saat ini dalam kondisi aman di atas minimum.
                    </div>
                <?php else: ?>
                    <div class="divide-y divide-slate-100">
                        <?php foreach ($critical_products as $cp): ?>
                            <div class="py-3 flex items-center justify-between gap-3 first:pt-0 last:pb-0">
                                <div>
                                    <p class="text-sm font-semibold text-slate-800"><?= e($cp['name']) ?></p>
                                    <p class="text-xs text-slate-400 font-mono"><?= e($cp['sku']) ?> &bull; <span class="font-sans text-slate-500"><?= e($cp['category_name']) ?></span></p>
                                </div>
                                <div class="text-right">
                                    <span class="px-2.5 py-1 rounded-full text-xs font-bold bg-rose-100 text-rose-700 inline-block">
                                        Sisa: <?= number_format($cp['stock']) ?> unit
                                    </span>
                                    <p class="text-[10px] text-slate-400 mt-0.5">Min: <?= number_format($cp['minimum_stock']) ?> unit</p>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Script Chart.js Initialization -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // 1. Bar Chart: Barang Masuk vs Barang Keluar (7 Hari)
    const ctxMovement = document.getElementById('stockMovementChart').getContext('2d');
    const movementLabels = <?= json_encode($chart_labels) ?>;
    const inData = <?= json_encode($chart_in_data) ?>;
    const outData = <?= json_encode($chart_out_data) ?>;

    new Chart(ctxMovement, {
        type: 'bar',
        data: {
            labels: movementLabels,
            datasets: [
                {
                    label: 'Barang Masuk (IN)',
                    data: inData,
                    backgroundColor: 'rgba(79, 70, 229, 0.85)',
                    borderColor: 'rgb(79, 70, 229)',
                    borderWidth: 1.5,
                    borderRadius: 8,
                    maxBarThickness: 32
                },
                {
                    label: 'Barang Keluar (OUT)',
                    data: outData,
                    backgroundColor: 'rgba(245, 158, 11, 0.85)',
                    borderColor: 'rgb(245, 158, 11)',
                    borderWidth: 1.5,
                    borderRadius: 8,
                    maxBarThickness: 32
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    backgroundColor: '#0f172a',
                    titleFont: { size: 12, weight: 'bold' },
                    bodyFont: { size: 12 },
                    padding: 10,
                    cornerRadius: 8,
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': ' + context.parsed.y + ' unit';
                        }
                    }
                }
            },
            scales: {
                x: {
                    grid: { display: false },
                    ticks: { font: { size: 11, family: "'Plus Jakarta Sans', sans-serif" }, color: '#64748b' }
                },
                y: {
                    beginAtZero: true,
                    ticks: {
                        precision: 0,
                        font: { size: 11, family: "'Plus Jakarta Sans', sans-serif" },
                        color: '#64748b'
                    },
                    grid: { color: '#f1f5f9' }
                }
            }
        }
    });

    // 2. Doughnut Chart: Rasio Masuk vs Keluar
    const ctxRatio = document.getElementById('ratioDoughnutChart').getContext('2d');
    const totalIn = <?= (int)$total_in ?>;
    const totalOut = <?= (int)$total_out ?>;

    new Chart(ctxRatio, {
        type: 'doughnut',
        data: {
            labels: ['Barang Masuk', 'Barang Keluar'],
            datasets: [{
                data: [totalIn > 0 || totalOut > 0 ? totalIn : 1, totalIn > 0 || totalOut > 0 ? totalOut : 0],
                backgroundColor: [
                    'rgba(79, 70, 229, 0.9)',
                    'rgba(245, 158, 11, 0.9)'
                ],
                hoverBackgroundColor: [
                    'rgb(67, 56, 202)',
                    'rgb(217, 119, 6)'
                ],
                borderWidth: 2,
                borderColor: '#ffffff'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '72%',
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: '#0f172a',
                    padding: 10,
                    cornerRadius: 8,
                    callbacks: {
                        label: function(context) {
                            const val = context.parsed;
                            return context.label + ': ' + val + ' unit';
                        }
                    }
                }
            }
        }
    });
});
</script>

<?php require_once __DIR__ . '/../views/footer.php'; ?>