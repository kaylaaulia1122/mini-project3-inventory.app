</main>
    </div>

    <footer class="bg-white border-t border-slate-200/80 py-5 mt-auto no-print">
        <div class="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-400 gap-2">
            <div>
                <span class="font-bold text-slate-700">INVENTORY<span class="text-blue-600">PRO</span></span> &bull; Sistem Manajemen Persediaan Elektronik
            </div>
            <div>
                &copy; <?= date('Y') ?> Tugas Akhir Pemrograman Web &bull; All Rights Reserved.
            </div>
        </div>
    </footer>
</body>
</html>