<?php
require_once __DIR__ . '/../helpers/auth.php';
require_once __DIR__ . '/../helpers/escape.php';
require_login();
$user = current_user();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>INVENTORYPRO - Sistem Manajemen Persediaan</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; }
        @media print {
            header, aside, footer, .no-print { display: none !important; }
            body { background: white !important; }
            .print-full { width: 100% !important; max-width: 100% !important; margin: 0 !important; padding: 0 !important; }
        }
    </style>
</head>
<body class="bg-slate-100/80 font-sans text-slate-800 antialiased min-h-screen flex flex-col">

    <!-- Navbar Top -->
    <header class="bg-slate-900 text-white sticky top-0 z-40 shadow-lg border-b border-slate-800">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
            <div class="flex items-center gap-3">
                <a href="/inventory-app/public/dashboard.php" class="flex items-center gap-2.5 font-extrabold text-lg tracking-wide group">
                    <span class="bg-gradient-to-tr from-blue-600 to-indigo-600 text-white p-2 rounded-xl shadow-md shadow-blue-500/20 group-hover:scale-105 transition"><i class="fa-solid fa-boxes-packing"></i></span>
                    <span>INVENTORY<span class="text-blue-400">PRO</span></span>
                </a>
            </div>

            <!-- User Status & Logout -->
            <div class="flex items-center gap-4">
                <div class="text-right hidden sm:flex flex-col items-end">
                    <p class="text-sm font-semibold text-white leading-tight flex items-center gap-2">
                        <span><?= e($user['full_name']) ?></span>
                        <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                    </p>
                    <span class="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full mt-0.5 inline-block text-white shadow-sm <?= $user['role'] === 'admin' ? 'bg-indigo-600 border border-indigo-400/40' : 'bg-emerald-600 border border-emerald-400/40' ?>">
                        <i class="fa-solid <?= $user['role'] === 'admin' ? 'fa-shield-halved' : 'fa-user-gear' ?> text-[9px] mr-1"></i><?= e($user['role']) ?>
                    </span>
                </div>
                <a href="/inventory-app/public/logout.php" onclick="return confirm('Apakah Anda yakin ingin keluar dari sistem?');" class="bg-slate-800/80 hover:bg-rose-600 text-slate-300 hover:text-white px-3.5 py-2 rounded-xl text-xs font-semibold transition flex items-center gap-2 border border-slate-700/60 shadow-sm">
                    <i class="fa-solid fa-right-from-bracket"></i> <span class="hidden sm:inline">Keluar</span>
                </a>
            </div>
        </div>
    </header>

    <!-- Main App Container -->
    <div class="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 flex flex-col md:flex-row gap-6">
        <!-- Sidebar Navigation -->
        <?php
        $uri = $_SERVER['REQUEST_URI'];
        $is_dash = (strpos($uri, 'dashboard.php') !== false);
        $is_prod = (strpos($uri, '/products/') !== false);
        $is_in   = (strpos($uri, '/stock/in.php') !== false);
        $is_out  = (strpos($uri, '/stock/out.php') !== false);
        $is_hist = (strpos($uri, '/stock/history.php') !== false);
        ?>
        <aside class="w-full md:w-64 bg-white rounded-2xl p-4 border border-slate-200/80 shadow-sm h-fit no-print">
            <div class="px-3 pb-3 mb-2 border-b border-slate-100 flex items-center justify-between">
                <span class="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Navigasi Utama</span>
                <span class="text-[10px] px-2 py-0.5 rounded font-bold <?= $user['role'] === 'admin' ? 'bg-indigo-50 text-indigo-600' : 'bg-emerald-50 text-emerald-600' ?>">
                    <?= strtoupper($user['role']) ?> MODE
                </span>
            </div>
            <nav class="space-y-1.5">
                <a href="/inventory-app/public/dashboard.php" class="flex items-center gap-3 px-3 py-2.5 rounded-xl font-medium text-sm transition <?= $is_dash ? 'bg-blue-50 text-blue-700 font-semibold shadow-xs' : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900' ?>">
                    <i class="fa-solid fa-chart-pie w-5 <?= $is_dash ? 'text-blue-600' : 'text-slate-400' ?>"></i> Dashboard
                </a>
                <a href="/inventory-app/public/products/index.php" class="flex items-center gap-3 px-3 py-2.5 rounded-xl font-medium text-sm transition <?= $is_prod ? 'bg-emerald-50 text-emerald-700 font-semibold shadow-xs' : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900' ?>">
                    <i class="fa-solid fa-boxes-stacked w-5 <?= $is_prod ? 'text-emerald-600' : 'text-slate-400' ?>"></i> Master Produk
                </a>
                <a href="/inventory-app/public/stock/in.php" class="flex items-center gap-3 px-3 py-2.5 rounded-xl font-medium text-sm transition <?= $is_in ? 'bg-indigo-50 text-indigo-700 font-semibold shadow-xs' : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900' ?>">
                    <i class="fa-solid fa-circle-arrow-down w-5 <?= $is_in ? 'text-indigo-600' : 'text-slate-400' ?>"></i> Barang Masuk
                </a>
                <a href="/inventory-app/public/stock/out.php" class="flex items-center gap-3 px-3 py-2.5 rounded-xl font-medium text-sm transition <?= $is_out ? 'bg-amber-50 text-amber-700 font-semibold shadow-xs' : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900' ?>">
                    <i class="fa-solid fa-circle-arrow-up w-5 <?= $is_out ? 'text-amber-600' : 'text-slate-400' ?>"></i> Barang Keluar
                </a>
                <a href="/inventory-app/public/stock/history.php" class="flex items-center gap-3 px-3 py-2.5 rounded-xl font-medium text-sm transition <?= $is_hist ? 'bg-purple-50 text-purple-700 font-semibold shadow-xs' : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900' ?>">
                    <i class="fa-solid fa-clock-rotate-left w-5 <?= $is_hist ? 'text-purple-600' : 'text-slate-400' ?>"></i> Histori Stok
                </a>
            </nav>

            <div class="mt-6 pt-4 border-t border-slate-100 px-3">
                <div class="flex items-center gap-2.5 text-xs text-slate-500">
                    <i class="fa-solid fa-circle-info text-blue-500"></i>
                    <span>Sistem Persediaan Elektronik</span>
                </div>
            </div>
        </aside>

        <!-- Dynamic Content Area -->
        <main class="flex-1 min-w-0"></main>